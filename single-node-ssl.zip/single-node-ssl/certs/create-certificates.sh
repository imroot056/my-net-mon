#Kibana Cert
#openssl genrsa -out kibana-key-temp.pem 4096
#openssl pkcs8 -inform PEM -outform PEM -in kibana-key-temp.pem -topk8 -nocrypt -v1 PBE-SHA1-3DES -out kibana-key.pem
#openssl req -new -key kibana-key.pem -out kibana.csr -subj "/C=NP/L=Kathmandu/O=Vairav/OU=CSOC/CN=kibana"
#openssl x509 -req -days 3652 -in kibana.csr -CA root-ca.pem -CAkey root-ca-key.pem -CAcreateserial -sha256 -out kibana.pem

#Elasticsearch Admin
openssl genrsa -out admin-key-temp.pem 4096
openssl pkcs8 -inform PEM -outform PEM -in admin-key-temp.pem -topk8 -nocrypt -v1 PBE-SHA1-3DES -out admin-key.pem
openssl req -new -key admin-key.pem -out admin.csr -subj "/C=NP/L=Kathmandu/O=Vairav/OU=CSOC/CN=admin"
openssl x509 -req -days 3652 -in admin.csr -CA root-ca.pem -CAkey root-ca-key.pem -CAcreateserial -sha256 -out admin.pem

#Elasticsearch Node
#openssl genrsa -out es-key-temp.pem 4096
#openssl pkcs8 -inform PEM -outform PEM -in es-key-temp.pem -topk8 -nocrypt -v1 PBE-SHA1-3DES -out es-key.pem
#openssl req -new -key es-key.pem -out es.csr -subj "/C=NP/L=Kathmandu/O=Vairav/OU=CSOC/CN=es"
#openssl x509 -req -days 3652 -in es.csr -CA root-ca.pem -CAkey root-ca-key.pem -CAcreateserial -sha256 -out es.pem

#Keycloak
#openssl genrsa -out keycloak-key-temp.pem 4096
#openssl pkcs8 -inform PEM -outform PEM -in keycloak-key-temp.pem -topk8 -nocrypt -v1 PBE-SHA1-3DES -out keycloak-key.pem
#openssl req -new -key keycloak-key.pem -out keycloak.csr -subj "/C=NP/L=Kathmandu/O=Vairav/OU=CSOC/CN=keycloak"
#openssl x509 -req -days 3652 -in keycloak.csr -CA root-ca.pem -CAkey root-ca-key.pem -CAcreateserial -sha256 -out keycloak.pem

#Wazuh
#openssl genrsa -out wazuh-key-temp.pem 4096
#openssl pkcs8 -inform PEM -outform PEM -in wazuh-key-temp.pem -topk8 -nocrypt -v1 PBE-SHA1-3DES -out wazuh-key.pem
#openssl req -new -key wazuh-key.pem -out wazuh.csr -subj "/C=NP/L=Kathmandu/O=Vairav/OU=CSOC/CN=wazuh"
#openssl x509 -req -days 3652 -in wazuh.csr -CA root-ca.pem -CAkey root-ca-key.pem -CAcreateserial -sha256 -out wazuh.pem



rm -rf *-temp.pem
